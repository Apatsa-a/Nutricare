# NutriCare — runnable development foundation

Developed by Apatsa Kabondo. Responsive web app for Android browsers, tablets and desktop.

## Stack
- React + TypeScript + Vite frontend
- Express + TypeScript API
- SQLite (persistent local development database in `data/nutricare.sqlite`)
- JWT authentication, bcrypt password hashing, server-side role middleware
- Recharts for dashboard visualisation

## Run locally
Requirements: Node.js 20+ and npm.

```bash
npm install
# Set a unique JWT secret before any deployment. For local testing:
# Linux/macOS: export JWT_SECRET='a-long-random-secret'
# PowerShell: $env:JWT_SECRET='a-long-random-secret'
npm run dev
```
Open the Vite URL printed in the terminal (normally http://localhost:5173). The API runs on port 4000. Database is created automatically in `data/`.

Build check:
```bash
npm run build
```

## First administrator
The public registration route intentionally cannot create an administrator. For local development, register a normal account, then promote it directly in the local SQLite database:

```sql
UPDATE users SET role='admin' WHERE email='your-email@example.com';
```
Sign out and sign in again to refresh the role in the JWT. Do not expose this local database procedure as a production admin workflow.

## Implemented in this build
- Registration and login; bcrypt password hashes; signed bearer tokens; server-side role gates.
- Roles: admin, professional, student, patient, clinic administrator. Patient-facing self-service is not complete; patient role currently receives a restricted dashboard and cannot query practitioner patient endpoints.
- Professional patient registration and owner-scoped patient records.
- Persisted anthropometric/clinical/dietary assessment records.
- PES statement creation and storage.
- Nutrition intervention and monitoring record creation.
- BMI, adult Mifflin–St Jeor estimate, Holliday–Segar calculation.
- Food record CRUD, CSV import route, searchable food library; imported/manual entries are unverified by default.
- Recipe ingredient storage and nutrient aggregation for selected available fields.
- Appointment creation/listing.
- Seven-day trial metadata, subscription settings, payment submissions, manual admin approval/rejection, subscription activation, audit events.
- Student fictional case descriptions.
- Patient-directory CSV export.

## Not yet production-ready / awaiting external inputs
- MAFOODS 2019 source dataset and permission to import/redistribute. No MAFOODS nutrient values are fabricated or bundled.
- WHO growth standards and Fenton reference datasets; LMS calculations and paediatric Z-score validation.
- Full patient portal, patient-specific login-to-patient linkage, messaging, consent workflows and self-service records.
- Full clinical modules, validated screening tools, dietary recall analysis, micronutrients, nutrient reference comparison, full meal-plan persistence and clinical decision support.
- Cooking yield, edible portion and nutrient-retention calculations in recipe analysis.
- PDF reports, complete analytics, role/clinic membership management, user role management UI.
- Subscription enforcement/feature entitlements, annual/monthly term selection, refunds and automated payment integrations. Manual approval currently activates a fixed 360-day subscription; adjust this before commercial use.
- Offline encrypted storage and sync/conflict handling. The app does not claim offline sync is working.
- Production PostgreSQL migration, secure httpOnly sessions, CSRF protection, rate limiting, MFA, encryption at rest, backup/recovery, security review, legal review and hosting configuration.

## Important security and clinical warnings
This is an early functional development build, not a validated clinical product or medical device. Do not enter identifiable real patient data or use outputs to prescribe care. Before pilot deployment, implement production security controls, clinical validation, governance, privacy/legal review and backups. The default JWT secret is development-only and MUST be replaced. CORS is permissive for local development. No production deployment should use these defaults.

CSV importer currently supports simple comma-separated rows and does not parse quoted commas. Validate imported data and source permissions before use. Unknown nutrient values must remain blank; do not convert blanks to zero.

## Brand/support
- NutriCare
- Developer: Apatsa Kabondo
- WhatsApp: 0883241810
- Email: apatsakabondo87@gmail.com
- Currency: MWK
