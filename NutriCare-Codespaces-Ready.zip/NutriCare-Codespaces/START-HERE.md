# Start NutriCare in GitHub Codespaces

This archive is arranged with `package.json` at the repository root and includes a Codespaces development-container configuration.

## Recommended: GitHub Codespaces
1. Create a new **private** repository on GitHub named `nutricare`.
2. Upload the contents of this folder to the repository (upload the files inside this folder, not the ZIP itself).
3. On the repository page, choose **Code → Codespaces → Create codespace on main**.
4. Wait for the development container and `npm install` to finish.
5. In the terminal run `npm run dev`.
6. Open the forwarded **5173** port to view the app. The API uses port **4000**.

If the automatic install fails, run `npm install --no-audit --no-fund` in the repository terminal and inspect the first error. The project uses `better-sqlite3`, a native Node module; Codespaces' Linux environment supports it, but a failed native build must be fixed rather than bypassed.

## Local computer
Requires Node.js 20+ and npm. Open a terminal in the folder containing `package.json`, then run:

```bash
npm install
npm run dev
```

Open `http://localhost:5173`.

## Important
This is a development build, not approved for real patient information or production clinical use. Use fictional test records only. MAFOODS and WHO reference datasets still require authorised source files and validation. Production security, PostgreSQL migration, backup, privacy/legal review and clinical validation remain outstanding.
